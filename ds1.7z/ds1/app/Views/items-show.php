<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/styles.css">
    <title>Items</title>
</head>
<body>
    <br>
    <table  align=center>
        <thead>
            <td>ID</td>
            <td>NOME</td>
            <td>IDADE</td>
            <td>DESCR</td>
            <td>DELETAR</td>
            <td>EDITAR</td>
        </thead>
        <?php
            foreach($data as $row){
                echo "<tr>";
                echo "<td>$row[id]</td>";
                echo "<td>$row[nome]</td>";
                echo "<td>$row[idade]</td>";
                echo "<td>$row[descr]</td>";
                echo "<td><a href=/deleteItem/$row[id]>Deletar</a></td>";
                echo "<td><a href=/showEditForm/$row[id]>Editar</a></td>";
                echo "</tr>";
            }
        ?>
    </table>
    <br>
    <div align=center>
        <a href="/showItemForm">Registrar novo</a>
    </div>
</body>
</html>