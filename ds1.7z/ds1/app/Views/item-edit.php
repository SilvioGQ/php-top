<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/styles.css">
    <title>Edit Item</title>
</head>
<body style='color:white; font-size:20px'>
    <form action="/editItem" method="post">
        <input type="hidden" name="id" value=<?php echo "$data[id]";?>>
        Nome:<input type="text" name="nome" value=<?php echo "$data[nome]";?> >
        <br>
        Idade:<input type="text" name="idade" value=<?php echo "$data[idade]";?>>
        <br>
        Descrição:<input type="text" name="descr" value=<?php echo "$data[descr]";?>>
        <br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>